# VueBlogger

VueBlogger is a light-weight blogging site generator for Vue.js, built for geeks who wanted to write their blog site in Vue and write posts in Markdown.

I developed it for a reason: there isn't really a simple blogging tool for Vue. VuePress works, but it's to complicated. So for that purpose, I developed this light-weight blogging site for Vue: VueBlogger.

You can host it on any server that has Nodejs and Vue installed. Actually, you even don't need them if you already built your blog on your own laptop: just host the HTML and JavaScript files directly!

## Usage

Please refer to the [documentation](https://samzhangjy.github.io/#/posts/vue-blogger).
